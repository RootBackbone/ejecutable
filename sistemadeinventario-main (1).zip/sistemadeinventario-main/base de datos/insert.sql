INSERT INTO producto (nombre, descripcion, unidades, costo, precio, categoria)
VALUES
	('Yerba Marolio', 'Suave 1kg', 5, 600, 800, 'Alimentos'),
	('Azucar Chango', '1kg', 5, 180, 200, 'Alimentos'),
	('Leche La Verónica', '1lt', 7, 130, 180, 'Alimentos');

INSERT INTO usuario (nombre, contrasenia, administrador)
VALUES
	('admin', 'root', 1),
	('guille', '1234', 0),
	('luchi', 'dg1234', 0),
	('mario', 'abcd', 1);