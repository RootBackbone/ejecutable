Este es un proyecto Maven Java Web creado en NetBeans 12.6 con el JDK 11 y el Apache Tomcat 8.5.83.

En la carpeta base de datos se encuentra el archivo .yml para levantar la base de datos MySQL en Docker con la configuracion necesaria para este proyecto y tambien se encuentra un archivo create.sql para crear las tablas.